# -*- coding:utf-8 -*-
import execjs,requests,random
import base64,codecs
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad
from nonebot import on_command, CommandSession
import json
__plugin_name__ = '网易云音乐 示例/wyy 新地球'
__plugin_usage__ = r"""
示例 /wyy 新地球[歌曲名]
"""
def to_16(key):
    while len(key) % 16 != 0:
        key += '\0'
    return str.encode(key)

def AES_encrypt(text, key, iv):
    bs = AES.block_size
    pad2 = lambda s: s + (bs - len(s) % bs) * chr(bs - len(s) % bs)
    encryptor = AES.new(to_16(key), AES.MODE_CBC, to_16(iv))

    pd2 = pad(str.encode(pad2(text)), 16)

    encrypt_aes = encryptor.encrypt(pd2)
    encrypt_text = str(base64.encodebytes(encrypt_aes), encoding='utf-8')
    return encrypt_text

def RSA_encrypt(text, pubKey, modulus):
    text = text[::-1]
    rs = int(codecs.encode(text.encode('utf-8'), 'hex_codec'), 16) ** int(pubKey, 16) % int(modulus, 16)
    return format(rs, 'x').zfill(256)


#获取i值的函数，即随机生成长度为16的字符串
get_i=execjs.compile(r"""
    function a(a) {
        var d, e, b = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789", c = "";
        for (d = 0; a > d; d += 1)
            e = Math.random() * b.length,
            e = Math.floor(e),
            c += b.charAt(e);
        return c
    }
""")


@on_command('wyy', aliases=('网易云音乐', '网易云'))
async def _(session: CommandSession):
    m_name = session.current_arg_text.strip()
    await session.send('正在从网易云音乐获取' + m_name + '\n')
    if m_name:
        wyy = WangYiYun()
        ret = wyy.get_wyy_kwd(m_name)
        music_id = ret['result']['songs'][0]['id']
        music_name = ret['result']['songs'][0]['name']
        wyy_report = '音乐名：' + music_name + '，音乐id：' + str(music_id) + '\n'
        await session.send(at_sender=True, message=wyy_report)
        if music_id:
            wyy_report = wyy.get_wyy_playurl(music_id, music_name)
            await session.send(at_sender=True, message=wyy_report)

    else:
        await session.send('获取失败，请更换名称再试试吧')









class WangYiYun():
    def __init__(self):
        self.csrf_token = '输入自己的token 抓包web网易云音乐获取token及MUSIC_U'
        self.g = '0CoJUm6Qyw8W8jud'
        self.b = "010001"
        self.c = '00e0b509f6259df8642dbc35662901477df22677ec152b5ff68ace615bb7b725152b3ab17a876aea8a5aa76d2e417629ec4ee341f56135fccf695280104e0312ecbda92557c93870114af6c9d05c4f7f0c3685b7a46bee255932575cce10b424d813cfe4875d3e82047b97ddef52741d546b8e289dc6935b3ece0462db0a22b8e7'
        self.i = get_i.call('a', 16)
        self.iv = "0102030405060708"
        # if not os.path.exists("d:/music"):
        #     os.mkdir('d:/music')
        self.ua = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.152 Safari/537.36'

    def get_encSecKey(self):
        return RSA_encrypt(self.i, self.b, self.c)

    def get_wyy_kwd(self, keyword):

        url = 'https://music.163.com/weapi/cloudsearch/get/web?csrf_token=' + self.csrf_token
        encText = str({'hlpretag': '<span class=\"s-fc7\">', 'hlposttag': '</span>', '#/discover': '', 's': keyword, 'type': '1', 'offset': "0", 'total': 'true', 'limit': '30', 'csrf_token': self.csrf_token})
        params = AES_encrypt(AES_encrypt(encText, self.g, self.iv), self.i, self.iv)
        data = {
            'params': params,
            'encSecKey': self.get_encSecKey()
        }

        header = {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Host': 'music.163.com',
            'Referer': 'https://music.163.com/search/',
            'User-Agent': self.ua
        }
        ret = requests.post(url, headers=header, data=data)
        # print('搜索结果', ret.text)
        return ret.json()


    def get_wyy_playurl(self, music_id, music_name='未获取到音乐名'+str(random.randint(10,99))):

        url = 'https://music.163.com/weapi/song/enhance/player/url?csrf_token=' + self.csrf_token
        encText = str({'ids': "[" + str(music_id) + "]", 'br': 128000, 'csrf_token': self.csrf_token, 'MUSIC_U': '输入自己的music_u'})
        params = AES_encrypt(AES_encrypt(encText, self.g, self.iv), self.i, self.iv)
        data = {
            'params': params,
            'encSecKey': self.get_encSecKey()
        }
        headeer = {
            'User-Agent': self.ua,
            'Referer': 'https://music.163.com/',
            'Content-Type': 'application/x-www-form-urlencoded'
        }

        ret = requests.post(url, headers=headeer, data=data).json()
        download_url = ret['data'][0]['url']
        if download_url:
            try:
                msg = {'music_name': music_name, 'play_url': download_url}
                # 根据音乐url地址，用urllib.request.retrieve直接将远程数据下载到本地
                # urllib.request.urlretrieve(download_url, 'd:/music/' + music_name+ '.mp3')
                # print('Successfully Download:'+music_name+ '.mp3')
            except:
                msg = {'msg': '出错了~'}
        else:
            msg = {'msg': '获取失败'}
        # print(msg)
        return json.dumps(msg)



# if __name__ == '__main__':
#     wyy = WangYiYun()
#     # 搜索内容
#     ret = wyy.get_wyy_kwd('新地球')
#     music_id = ret['result']['songs'][0]['id']
#     music_name = ret['result']['songs'][0]['name']
#     print(music_name, music_id)
#     if music_id:
#         wyy.get_wyy_playurl(music_id, music_name)