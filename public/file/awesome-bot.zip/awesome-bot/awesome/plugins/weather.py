from nonebot import on_command, CommandSession
from nonebot import on_natural_language, NLPSession, IntentCommand
import requests
from jieba import posseg
__plugin_name__ = '天气查询 示例/天气 北京'
__plugin_usage__ = r"""
示例 /天气[城市名]
"""
def get_tianqi(city):
    url = 'http://autodev.openspeech.cn/csp/api/v2.1/weather?openId=aiuicus&clientType=android&sign=android&city=' + city + '&needMoreData=true&pageNo=1&pageSize=1'
    ret = requests.get(url).json()
    if ret.get('msg', '') == '操作成功':
        title = ''
        if ret['data']['list'][0]['moreData'].get('alert', None) is not None:
            title = '\n' + '预警信息：' + ret['data']['list'][0]['moreData']['alert'][0]['title']
        txt = f'{city}当前的温度是'+str(ret['data']['list'][0]['temp'])+'度，'+ret['data']['list'][0]['weather']+'，空气'+ret['data']['list'][0]['airQuality']+'，PM2.5：'+str(ret['data']['list'][0]['pm25'])+title

    else:
        txt = 'null'
    # print(txt)
    return txt
# on_command 装饰器将函数声明为一个命令处理器
# 这里 weather 为命令的名字，同时允许使用别名「天气」「天气预报」「查天气」
@on_command('weather', aliases=('天气', '天气预报', '查天气'))
async def _(session: CommandSession):
    # 取得消息的内容，并且去掉首尾的空白符
    city = session.current_arg_text.strip()
    # 如果除了命令的名字之外用户还提供了别的内容，即用户直接将城市名跟在命令名后面，
    # 则此时 city 不为空。例如用户可能发送了："天气 南京"，则此时 city == '南京'
    # 否则这代表用户仅发送了："天气" 二字，机器人将会向其发送一条消息并且等待其回复
    if not city:
        city = (await session.aget(prompt='你想查询哪个城市的天气呢？')).strip()
        # 如果用户只发送空白符，则继续询问
        while not city:
            city = (await session.aget(prompt='要查询的城市名称不能为空呢，请重新输入')).strip()
    # 获取城市的天气预报
    weather_report = get_tianqi(city)
    # 向用户发送天气预报
    await session.send(weather_report)

@on_natural_language(keywords={'天气'})
async def _(session: NLPSession):
    # 去掉消息首尾的空白符
    stripped_msg = session.msg_text.strip()
    # 对消息进行分词和词性标注
    words = posseg.lcut(stripped_msg)

    city = None
    # 遍历 posseg.lcut 返回的列表
    for word in words:
        # 每个元素是一个 pair 对象，包含 word 和 flag 两个属性，分别表示词和词性
        if word.flag == 'ns':
            # ns 词性表示地名
            city = word.word
            break

    # 返回意图命令，前两个参数必填，分别表示置信度和意图命令名
    return IntentCommand(90.0, 'weather', current_arg=city or '')

# async def get_weather_of_city(city: str) -> str:
#     # 这里简单返回一个字符串
#     # 实际应用中，这里应该调用返回真实数据的天气 API，并拼接成天气预报内容
#     return f'{city}今天的' + get_tianqi(city)