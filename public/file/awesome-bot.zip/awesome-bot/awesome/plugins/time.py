from datetime import timedelta
from datetime import datetime
from datetime import timezone
from nonebot import on_command, CommandSession

__plugin_name__ = '时间查询 示例/time'
__plugin_usage__ = r"""
示例/time
"""
def get_Beijing():
    SHA_TZ = timezone(
        timedelta(hours=8),
        name='Asia/Shanghai',
    )

    utc_now = datetime.utcnow().replace(tzinfo=timezone.utc)
    beijing_now = utc_now.astimezone(SHA_TZ)
    return '北京时间：' + str(beijing_now.date()) + ' ' + str(beijing_now.strftime('%H:%M:%S'))

@on_command('time', aliases=('时间', '几点了', '北京时间'))
async def _(session: CommandSession):
    time_report = get_Beijing()
    await session.send(time_report)