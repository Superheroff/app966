# encoding:utf-8
from tcping import Ping
from nonebot import on_command, CommandSession
__plugin_name__ = 'ping域名 示例/ping www.app966.com'
__plugin_usage__ = r"""
示例 /ping www.app966.com
"""


@on_command('ping')
async def _(session: CommandSession):
    ip = session.current_arg_text.strip()
    if not ip:
        ip = (await session.aget(prompt='请输入你想要ping的ip或域名')).strip()
        while not ip or ip == '127.0.0.1':
            ip = (await session.aget(prompt='错误，不能ping空不能ping我')).strip()
    await session.send('正在ping[{0}]请稍后，结果以表格展示'.format(ip))
    ping = Ping(ip, 80, 60)
    ping.ping(4)
    ret = ping.result.table
    await session.send(ret)






