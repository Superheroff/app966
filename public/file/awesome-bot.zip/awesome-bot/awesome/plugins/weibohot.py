import requests
from lxml import etree
from nonebot import on_command, CommandSession
__plugin_name__ = '微博热搜榜 示例/热搜 10[条数默认10，>15将逐条获取]'
__plugin_usage__ = r"""
示例 /weibohot 10[条数默认10，>15将逐条获取]
"""
@on_command('weibohot', aliases=('热搜', '微博热搜'))
async def get_weibohot(session: CommandSession):
    num = session.current_arg_text.strip()
    if not num:
        num = '10'
    await session.send("正在获取微博热搜榜：")
    url = 'https://passport.weibo.com/visitor/visitor?a=incarnate&t=LomBgTEURrl3AoXFT346PaH7q%2FNDphe9Xzpc1S3RCJ4%3D&w=2&c=095&gc=&cb=cross_domain&from=weibo&_rand=0.00811768666053514'
    headers = {
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.90 Safari/537.36',
    }
    response = requests.get(url=url, headers=headers)
    cookie = requests.utils.dict_from_cookiejar(response.cookies)
    url = 'https://s.weibo.com/top/summary?cate=realtimehot'
    response = requests.get(url=url, headers=headers, cookies=cookie).text
    soup = etree.HTML(response)
    hot_name = soup.xpath('//div[@class="data"]//tr/td[@class="td-02"]/a/text()')
    hot_int = soup.xpath('//div[@class="data"]//tr/td[@class="td-02"]/span/text()')
    # https://s.weibo.com
    hot_url = soup.xpath('//div[@class="data"]//tr/td[@class="td-02"]/a/@href')
    n = 0
    txt = ''
    for i in hot_name:
        hot_ints = hot_int[n-1] if n > 0 else ''
        if int(num) > 15:
            txt = "{0}" + i + '，热度：' + hot_ints + '\n 详情：https://s.weibo.com' + hot_url[n]
            txt = txt.format('【置顶】' if hot_ints == '' else str(n) + '.')
            await session.send(txt)
        else:
            txt += "{0}" + i + '，热度：' + hot_ints + '\n 详情：https://s.weibo.com' + hot_url[n] + '\n'
            txt = txt.format('【置顶】' if hot_ints == '' else str(n) + '.')
        n += 1
        if n >= (int(num) + 1):
            if int(num) <= 15:
                await session.send(txt)
            await session.send("微博热搜榜获取完毕共" + str(n) + "条")
            break

# if __name__ == '__main__':
#     get_weibohot()



