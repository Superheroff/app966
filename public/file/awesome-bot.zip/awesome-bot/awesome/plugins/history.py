from datetime import datetime
import requests
import re
import random
from nonebot import on_command, CommandSession
__plugin_name__ = '历史上的今天 示例/历史'
__plugin_usage__ = r"""
示例 /历史
"""

def history():
    times = datetime.now()
    day = str(times.day)
    day = day.zfill(2)
    month = str(times.month)
    month = month.zfill(2)
    url = 'https://baike.baidu.com/cms/home/eventsOnHistory/{0}.json'.format(month)
    ret = requests.get(url, headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:102.0) Gecko/20100101 Firefox/102.0'}).json()
    # print(ret)
    txt = ret[month][month + day]
    txt = txt[random.randint(0, len(txt)-1)]
    txt = eval(re.sub(r'</?\w+[^>]*>', '', str(txt)))
    data = txt['year'] + '年' + month + '月' + day + '日，' + txt['title'] + '\n详情请点击：' + txt['link']
    return data

    # for i in ret[month][month + day]:
    #     n = eval(re.sub(r'</?\w+[^>]*>', '', str(i)))
    #     print(n['year'] + '年' + month + '月' + day + '日，' + n['title'])
    #     print(n['link'])



@on_command('history', aliases=('历史', '历史上的今天'))
async def _(session: CommandSession):
    await session.send(history())
