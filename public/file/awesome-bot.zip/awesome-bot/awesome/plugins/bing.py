import requests
from nonebot import on_command, CommandSession
__plugin_name__ = '必应壁纸 示例/bing 30[表示获取30天前]'
__plugin_usage__ = r"""
示例 /bing 30 [0=今天，+1=今天-1]
"""
def get_bing(uhd=False, day=0):
    """
    :param uhd:是否4k 默认否
    :param day: 0=今天 +1就是前一天
    :return:
    """

    url = 'https://cn.bing.com/HPImageArchive.aspx?format=js&idx={0}&n=1'.format(str(day))
    ret = requests.get(url).json()
    img = ret['images'][0]['url']
    copyright = ret['images'][0]['copyright']
    if not uhd:

        img = 'https://cn.bing.com' + img
    else:
        img = 'https://cn.bing.com/th?id=' + get_str_btw(img, 'id=', '_1920x1080') + '_UHD.jpg'

    return img, copyright


def get_str_btw(s, f, b):
    par = s.partition(f)
    return (par[2].partition(b))[0][:]


# img = get_bing(True)
# print(img)
@on_command('bing', aliases=('bing', '必应'))
async def _(session: CommandSession):
    day = session.current_arg_text.strip()
    if day == '0' or day == '':
        await session.send('正在获取今日的必应壁纸')
    else:
        await session.send('正在获取[{0}]天前的必应壁纸'.format(day))
    if not day:
        day = 0
    img_report, copyright = get_bing(True, day)
    bing_report = '图片描述：' + copyright + '\n' + '下载地址：' + img_report
    messages = [
        {
            "type": "text",
            "data": {"text": "必应壁纸\n"}
        },
        {
            "type": "image",
            "data": {
                "file": img_report}
        },
        {
            "type": "text",
            "data": {"text": bing_report}
        }
    ]

    await session.send(at_sender=True, message=messages)
