from nonebot.default_config import *
import re
from datetime import timedelta
TENCENT_BOT_SECRET_ID = '' # 这里申请 是免费的：https://cloud.tencent.com/product/nlp
TENCENT_BOT_SECRET_KEY = ''
NICKNAME = {'小Q', '小QQ', '/'}
HOST = '0.0.0.0'
PORT = 8080
SUPERUSERS = {838210720}
SESSION_EXPIRE_TIMEOUT = timedelta(minutes=2)
DEBUG = False
COMMAND_START = ['', re.compile(r'[/!]+')]