# -*- coding: utf-8 -*-
# @Time    : 2022/2/18 
# @Author  :
import os
import time
import requests
import shutil
from google.protobuf.json_format import MessageToDict
import json
from messages.message_pb2 import *
import base64
import asyncio

def getScriptDir():
    return os.path.split(os.path.realpath(__file__))[0]

class Watcher():
    def __init__(self):
        self.monitoringFile = f'{getScriptDir()}\\douyinLiveFile'

    async def startWatcher(self):
            files = os.listdir(self.monitoringFile)
            if files:
                for _ in files:
                    filepath = self.monitoringFile + '\\' + _
                    with open(filepath, 'rb') as f:
                        datas = {}
                        messages = []
                        danmu_resp = Response()
                        danmu_resp.ParseFromString(f.read())
                        f.close()
                        obj = MessageToDict(danmu_resp, preserving_proto_field_name=True)
                        if obj:
                            if obj.get('messages'):
                                datas.update({'now': obj.get('now')})
                                for message in obj["messages"]:
                                    method = message["method"]
                                    payload = bytes(base64.b64decode(message["payload"].encode()))
                                    if method == "WebcastMemberMessage":
                                        menber_message = MemberMessage()
                                        menber_message.ParseFromString(payload)
                                        obj1 = MessageToDict(menber_message, preserving_proto_field_name=True)
                                        obj1 = {'method': method, 'msgId': message['msgId'], 'payload': obj1}
                                        messages.append(obj1)
                                    if method == "WebcastChatMessage":
                                        menber_message5 = ChatMessage()
                                        menber_message5.ParseFromString(payload)
                                        obj2 = MessageToDict(menber_message5, preserving_proto_field_name=True)
                                        obj2 = {'method': method, 'msgId': message['msgId'], 'payload': obj2}
                                        messages.append(obj2)

                                datas.update({'data': messages})
                                ret = json.dumps(datas)
                                with open('./userImages/' + str(int(time.time())) + '.json', 'w') as file:
                                    file.write(ret)
                                    file.close()

                        else:
                            ret = {'msg': '请先运行webdriver获取弹幕文件'}

            print(ret)
            return ret

if __name__ == '__main__':
    if not os.path.isdir(getScriptDir()+"\\douyinLiveFile"):# 这里存放未解析的弹幕文件
        os.makedirs(getScriptDir()+"\\douyinLiveFile")
    if not os.path.isdir(getScriptDir()+"\\userImages"):# 这里存放解析好的json数据文件
        os.makedirs(getScriptDir()+"\\userImages")
    while True:
            time.sleep(1)
            asyncio.run(Watcher().startWatcher())
